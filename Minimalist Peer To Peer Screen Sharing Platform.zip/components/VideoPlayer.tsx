import React, { useEffect, useRef } from "react";
import styles from "./VideoPlayer.module.css";

interface VideoPlayerProps {
  stream: MediaStream;
  isMuted?: boolean;
}

export const VideoPlayer = ({ stream, isMuted = false }: VideoPlayerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <video
      ref={videoRef}
      className={styles.video}
      autoPlay
      playsInline
      muted={isMuted}
    />
  );
};